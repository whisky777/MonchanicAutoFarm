package com.example.monchanicautofarm;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.content.SharedPreferences;

public class TapAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private boolean tapInProgress = false;

    private final Runnable tapLoop = new Runnable() {
        @Override public void run() {
            if (prefs == null || !prefs.getBoolean("running", false)) {
                handler.postDelayed(this, 500);
                return;
            }
            if (!tapInProgress) {
                int x = prefs.getInt("x", 350);
                int y = prefs.getInt("y", 1300);
                Path path = new Path();
                path.moveTo(x, y);
                GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(path, 0, 60);
                GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
                tapInProgress = true;
                boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) { tapInProgress = false; }
                    @Override public void onCancelled(GestureDescription g) { tapInProgress = false; }
                }, null);
                if (!dispatched) tapInProgress = false;
            }
            int interval = Math.max(500, prefs.getInt("interval", 1500));
            handler.postDelayed(this, interval);
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences("farm", MODE_PRIVATE);
        handler.removeCallbacks(tapLoop);
        handler.post(tapLoop);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {
        if (prefs != null) prefs.edit().putBoolean("running", false).apply();
    }
    @Override public void onDestroy() {
        handler.removeCallbacks(tapLoop);
        super.onDestroy();
    }
}
