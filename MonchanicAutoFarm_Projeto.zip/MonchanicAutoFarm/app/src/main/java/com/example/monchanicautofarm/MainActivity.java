package com.example.monchanicautofarm;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText intervalInput, xInput, yInput;
    TextView status;
    SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("farm", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(250, 240, 248));

        TextView title = new TextView(this);
        title.setText("MONCHANIC AUTO FARM");
        title.setTextSize(23);
        title.setTextColor(Color.rgb(35, 25, 35));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 18);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Assistente simples de toques repetidos. Configure um ponto seguro da tela e teste primeiro fora de batalhas importantes.");
        info.setTextSize(15);
        info.setTextColor(Color.DKGRAY);
        root.addView(info);

        intervalInput = field(root, "Intervalo entre toques (ms; mínimo 500)", String.valueOf(prefs.getInt("interval", 1500)));
        xInput = field(root, "Coordenada X do toque (pixels)", String.valueOf(prefs.getInt("x", 350)));
        yInput = field(root, "Coordenada Y do toque (pixels)", String.valueOf(prefs.getInt("y", 1300)));

        Button save = button("Salvar configurações");
        root.addView(save);
        save.setOnClickListener(v -> saveSettings());

        Button accessibility = button("1. Ativar serviço de acessibilidade");
        root.addView(accessibility);
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button start = button("2. INICIAR TOQUES");
        root.addView(start);
        start.setOnClickListener(v -> {
            saveSettings();
            prefs.edit().putBoolean("running", true).apply();
            status.setText("Status: solicitado. Volte ao jogo; use a notificação/configurações de acessibilidade para parar.");
            Toast.makeText(this, "Automação solicitada", Toast.LENGTH_SHORT).show();
        });

        Button stop = button("PARAR TOQUES");
        root.addView(stop);
        stop.setOnClickListener(v -> {
            prefs.edit().putBoolean("running", false).apply();
            status.setText("Status: parado");
            Toast.makeText(this, "Automação parada", Toast.LENGTH_SHORT).show();
        });

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextColor(Color.rgb(90, 25, 80));
        status.setPadding(0, 18, 0, 12);
        root.addView(status);
        status.setText(prefs.getBoolean("running", false) ? "Status: solicitado" : "Status: parado");

        TextView warning = new TextView(this);
        warning.setText("Use somente onde permitido pelas regras do jogo. O app não detecta inimigos nem avança decisões sozinho; ele apenas repete toques no ponto escolhido. Para parar imediatamente, toque em PARAR TOQUES.");
        warning.setTextSize(13);
        warning.setTextColor(Color.DKGRAY);
        warning.setPadding(0, 10, 0, 0);
        root.addView(warning);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    EditText field(LinearLayout root, String label, String value) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(0, 14, 0, 4);
        root.addView(t);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(value);
        e.setInputType(2);
        root.addView(e);
        return e;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    void saveSettings() {
        try {
            int interval = Math.max(500, Integer.parseInt(intervalInput.getText().toString().trim()));
            int x = Math.max(0, Integer.parseInt(xInput.getText().toString().trim()));
            int y = Math.max(0, Integer.parseInt(yInput.getText().toString().trim()));
            prefs.edit().putInt("interval", interval).putInt("x", x).putInt("y", y).apply();
            Toast.makeText(this, "Configurações salvas", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Confira os números informados", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onPause() { super.onPause(); }
}
