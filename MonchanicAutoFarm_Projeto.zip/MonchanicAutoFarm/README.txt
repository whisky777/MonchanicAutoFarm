MONCHANIC AUTO FARM — PROJETO ANDROID

O que faz:
- Repetição de toques em coordenadas de tela configuradas pelo usuário.
- Intervalo configurável, com mínimo de 500 ms.
- Botão para iniciar e parar.

Limitações:
- Este pacote é o CÓDIGO-FONTE de um projeto Android Studio, não um APK já compilado.
- Não reconhece inimigos, não toma decisões de jogo e não garante avanço automático.
- O toque depende de o serviço de Acessibilidade estar ativado e das coordenadas corretas para o tamanho/resolução do aparelho.
- A automação pode ser proibida pelas regras do jogo. Use por sua conta e risco e pare se causar ações inesperadas.

Como gerar o APK:
1. Instale Android Studio em um computador.
2. Abra a pasta MonchanicAutoFarm no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Vá em Build > Build APK(s).
5. O APK de debug será gerado em app/build/outputs/apk/debug/.

Como usar:
1. Instale o APK compilado.
2. Abra o app e configure X/Y e o intervalo.
3. Toque em “Ativar serviço de acessibilidade” e habilite o serviço “Monchanic Auto Farm - Toques”.
4. Volte ao app, salve e toque em “INICIAR TOQUES”.
5. Para parar, abra o app e toque em “PARAR TOQUES”.

Dica: teste primeiro em uma tela sem consequências. As coordenadas são pixels e variam por aparelho. Nunca deixe rodando sem supervisão.
